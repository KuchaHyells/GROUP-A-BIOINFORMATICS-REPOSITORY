print("Name: Kuchahyells Mathias")
print("Email: damysteriesj@gmail.com")
print("Slack username: Kuchahyells Mathias")
print("interest: Proteomics and Data Analysis")
